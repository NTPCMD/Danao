import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import logo from 'figma:asset/2cf30faefbae4be7b13c2aec7d9e30456795e0fa.png';

export function Footer() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.3,
  });

  const serviceCategories = [
    'Personal Concierge',
    'Business Concierge',
    'Event Concierge',
    'Logistics Concierge',
    'Digital Concierge',
    'Premium Support',
  ];

  return (
    <footer className="bg-black border-t border-gray-900 relative overflow-hidden" ref={ref}>
      {/* Gold line reveal */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={inView ? { scaleX: 1 } : {}}
        transition={{ duration: 1.5, ease: 'easeInOut' }}
        className="absolute top-0 left-0 right-0 h-[2px] bg-[#C9A961] origin-left"
      />

      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Logo and description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <img src={logo} alt="Danao Group" className="h-12 w-auto mb-4" />
            <p className="text-gray-400">
              Premium concierge and multi-industry services across Australia.
            </p>
          </motion.div>

          {/* Service categories */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="mb-4 text-[#C9A961]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Services
            </h3>
            <ul className="space-y-2">
              {serviceCategories.map((category) => (
                <li key={category}>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-[#C9A961] transition-colors duration-300"
                  >
                    {category}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="mb-4 text-[#C9A961]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Contact
            </h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a
                  href="tel:1300000000"
                  className="hover:text-[#C9A961] transition-colors duration-300"
                >
                  1300 000 000
                </a>
              </li>
              <li>
                <a
                  href="mailto:concierge@danaogroup.com"
                  className="hover:text-[#C9A961] transition-colors duration-300"
                >
                  concierge@danaogroup.com
                </a>
              </li>
              <li className="pt-2">
                <p>Australia Wide</p>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Copyright */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="border-t border-gray-900 pt-8 text-center text-gray-500"
        >
          <p>&copy; {new Date().getFullYear()} Danao Group. All rights reserved.</p>
        </motion.div>
      </div>
    </footer>
  );
}