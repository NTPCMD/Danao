import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import { User, Briefcase, Calendar, Truck, Smartphone, Headphones } from 'lucide-react';

const services = [
  {
    title: 'Personal Concierge',
    icon: User,
    description: 'Personalized assistance for your daily needs and lifestyle management',
  },
  {
    title: 'Business Concierge',
    icon: Briefcase,
    description: 'Professional support for your business operations and requirements',
  },
  {
    title: 'Event Concierge',
    icon: Calendar,
    description: 'Comprehensive event planning and coordination services',
  },
  {
    title: 'Logistics Concierge',
    icon: Truck,
    description: 'Seamless logistics and delivery management solutions',
  },
  {
    title: 'Digital Concierge',
    icon: Smartphone,
    description: 'Tech-enabled assistance for all your digital needs',
  },
  {
    title: 'Premium Support Concierge',
    icon: Headphones,
    description: 'Priority access to our dedicated support team',
  },
];

export function ServicesGrid() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section className="py-24 px-6 bg-black" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
          style={{ fontFamily: 'Playfair Display, serif' }}
        >
          <span className="text-4xl md:text-6xl text-white">Our Concierge Services</span>
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative bg-[#0A0A0A] border-2 border-[#C9A961] p-8 transition-all duration-300 hover:translate-y-[-8px] hover:shadow-[0_8px_40px_rgba(201,169,97,0.4)]"
              >
                <div className="mb-4">
                  <Icon className="w-12 h-12 text-[#C9A961]" />
                </div>
                <h3 className="mb-3 text-white" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {service.title}
                </h3>
                <p className="text-gray-400">{service.description}</p>

                {/* Hover glow effect */}
                <div className="absolute inset-0 border-2 border-[#C9A961] opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-md" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}