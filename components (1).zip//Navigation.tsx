import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import logo from 'figma:asset/2cf30faefbae4be7b13c2aec7d9e30456795e0fa.png';

export function Navigation() {
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/concierge', label: 'Concierge' },
    { path: '/services', label: 'Services' },
    { path: '/contact', label: 'Contact' },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-sm border-b border-[#C9A961]/20"
    >
      <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img src={logo} alt="Danao Group" className="h-12 w-auto" />
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center gap-8">
          {navLinks.map((link) => {
            const isActive = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`relative text-white transition-all duration-300 hover:text-[#C9A961] ${
                  isActive ? 'text-[#C9A961]' : ''
                }`}
              >
                <span style={{ fontFamily: 'Inter, sans-serif' }}>{link.label}</span>
                {/* Active indicator */}
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#C9A961]"
                    initial={false}
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                {/* Hover glow effect */}
                <span className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity duration-300 blur-md bg-[#C9A961]/30 -z-10" />
              </Link>
            );
          })}
        </div>
      </div>
    </motion.nav>
  );
}
