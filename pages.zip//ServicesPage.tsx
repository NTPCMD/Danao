import { useState, useEffect } from 'react';
import { HeroCustom } from '../components/HeroCustom';
import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import {
  Palette,
  Truck,
  Home,
  Briefcase,
  UtensilsCrossed,
  Sparkles,
  Clock,
  Shield,
  Users,
  Package,
  Building,
  PartyPopper,
} from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';
import { Footer } from '../components/Footer';

export function ServicesPage() {
  const [scrollY, setScrollY] = useState(0);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const serviceCategories = [
    {
      title: 'Digital & Creative',
      icon: Palette,
      description: 'Web design, branding, content creation, and digital marketing solutions.',
      services: ['Web Design', 'Branding', 'Content Creation', 'Digital Marketing'],
    },
    {
      title: 'Logistics & Transport',
      icon: Truck,
      description: 'Reliable logistics, freight, and transportation services across Australia.',
      services: ['Freight Services', 'Last-Mile Delivery', 'Fleet Management', 'Warehousing'],
    },
    {
      title: 'Property & Facilities',
      icon: Home,
      description: 'Property management, maintenance, and facilities services.',
      services: ['Property Management', 'Maintenance', 'Cleaning', 'Security'],
    },
    {
      title: 'Business & Corporate',
      icon: Briefcase,
      description: 'Business consulting, corporate services, and professional solutions.',
      services: ['Business Consulting', 'Corporate Events', 'Admin Support', 'Virtual Assistance'],
    },
    {
      title: 'Hospitality & Retail',
      icon: UtensilsCrossed,
      description: 'Hospitality management, retail solutions, and customer service excellence.',
      services: ['Restaurant Management', 'Retail Operations', 'Customer Service', 'Staff Training'],
    },
    {
      title: 'Events & Experiences',
      icon: PartyPopper,
      description: 'Event planning, coordination, and memorable experience creation.',
      services: ['Event Planning', 'Venue Coordination', 'Catering', 'Entertainment'],
    },
  ];

  const whyDanao = [
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Round-the-clock service and support whenever you need it.',
    },
    {
      icon: Shield,
      title: 'Trusted Partners',
      description: 'Vetted and reliable service providers across all industries.',
    },
    {
      icon: Users,
      title: 'Dedicated Team',
      description: 'Expert professionals committed to your success.',
    },
    {
      icon: Package,
      title: 'Tailored Solutions',
      description: 'Customized services to match your specific needs.',
    },
  ];

  return (
    <div className="bg-black text-white overflow-hidden pt-20">
      <HeroCustom
        scrollY={scrollY}
        title="Our Services"
        subtitle="Comprehensive multi-industry solutions designed to exceed expectations."
      />

      {/* Service Categories Grid */}
      <section ref={ref} className="py-24 px-6 bg-black">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Service Categories
            </h2>
            <div className="h-1 w-24 bg-[#C9A961] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {serviceCategories.map((category, index) => {
              const Icon = category.icon;
              return (
                <motion.div
                  key={category.title}
                  initial={{ opacity: 0, y: 40 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group relative bg-[#0A0A0A] border-2 border-[#C9A961] p-8 transition-all duration-300 hover:translate-y-[-8px] hover:shadow-[0_8px_40px_rgba(201,169,97,0.4)]"
                >
                  <div className="mb-4">
                    <Icon className="w-12 h-12 text-[#C9A961]" />
                  </div>
                  <h3 className="text-2xl mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {category.title}
                  </h3>
                  <p className="text-gray-400 mb-4">{category.description}</p>
                  <ul className="space-y-2">
                    {category.services.map((service) => (
                      <li key={service} className="text-gray-300 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#C9A961]" />
                        <span>{service}</span>
                      </li>
                    ))}
                  </ul>
                  {/* Hover glow effect */}
                  <div className="absolute inset-0 border-2 border-[#C9A961] opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-md" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Danao */}
      <section className="py-24 px-6 bg-[#0A0A0A]">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Why Choose Danao Group
            </h2>
            <div className="h-1 w-24 bg-[#C9A961] mx-auto" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyDanao.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 40 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group text-center p-6 border border-gray-800 hover:border-[#C9A961] transition-all duration-300 hover:shadow-[0_4px_30px_rgba(201,169,97,0.3)]"
                >
                  <div className="mb-4 flex justify-center">
                    <Icon className="w-12 h-12 text-[#C9A961] group-hover:scale-110 transition-transform duration-300" />
                  </div>
                  <h3 className="text-xl mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {item.title}
                  </h3>
                  <p className="text-gray-400">{item.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <ContactCTA />
      <Footer />
    </div>
  );
}