import { useState, useEffect } from 'react';
import { HeroCustom } from '../components/HeroCustom';
import { ServicesGrid } from '../components/ServicesGrid';
import { WhyChoose } from '../components/WhyChoose';
import { ContactCTA } from '../components/ContactCTA';
import { Footer } from '../components/Footer';

export function ConciergePage() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-black text-white overflow-hidden pt-20">
      <HeroCustom
        scrollY={scrollY}
        title="Danao Concierge Services"
        subtitle="Premium personal and business concierge solutions delivered with the Danao Gold Standard."
        button1Text="Book Consultation"
        button2Text="View Services"
      />
      <ServicesGrid />
      <WhyChoose />
      <ContactCTA />
      <Footer />
    </div>
  );
}